/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package eva1_8_copia_arreglos_2;

/**
 *
 * @author invitado
 */
public class EVA1_8_COPIA_ARREGLOS_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int aiDatosOrigen[]=new int[5];
        aiDatosOrigen[0]=10;
        aiDatosOrigen[1]=20;
        aiDatosOrigen[2]=30;
        aiDatosOrigen[3]=40;
        aiDatosOrigen[4]=50;
        int aiCopia[]=new int [aiDatosOrigen.length];//se inicializa con lo mismo del primero
        //NO SIRVE
        //aiCopia = aiDatosOrigen;
        for(int i=0; i< aiDatosOrigen.length;i++){
            aiCopia[i]=aiDatosOrigen[i];
        }
        //imprimir copia
        for(int i=0; i< aiCopia.length;i++){
            System.out.println(aiCopia[i]);
    }
        //modificar original
        aiDatosOrigen[3]=9999;
        //imprimir copia
        System.out.println("reimprimo copia");
           for(int i=0; i< aiCopia.length;i++){
            System.out.println(aiCopia[i]);
    }
           System.out.println(aiDatosOrigen);//al mandar la dirreccion si no son iguales son idependientes
           System.out.println(aiCopia);
}
}