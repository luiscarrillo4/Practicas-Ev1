/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Mary
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static final int ARRE_TAMA=30;//arre tama indica el tamaño
    public static void main(String[] args) {
        // TODO code application logic here
       int aiEdad[]=new int [ARRE_TAMA];//declaramos un identificador de tipo arreglo
        //los arreglos en java siempre empiezan en 0
        //hay que movernos a un  valor previo al tamaño del arreglo
        //for(int i=0;i<aiEdad.leght;i++) equivalente
        for(int i=0;i<ARRE_TAMA;i++){//leemos nuestro arreglo
            System.out.println("aiEdad[" + i +"]=" + aiEdad[i]);
        }
            aiEdad[0]=25;//posicion cero 
            //llenar con valore entre 0 y 36
           for(int i=0;i<aiEdad.length;i++){
               // math.random regresa valores entre 0 y 1
               //hay que haceer un casting de double a entero(int)
               
               aiEdad[i]= (int)(Math.random()*36);
           }
           for(int i=0;i<ARRE_TAMA;i++){//leemos nuestro arreglo
            System.out.println("aiEdad[" + i +"]=" + aiEdad[i]);
        }

    }
    
}
