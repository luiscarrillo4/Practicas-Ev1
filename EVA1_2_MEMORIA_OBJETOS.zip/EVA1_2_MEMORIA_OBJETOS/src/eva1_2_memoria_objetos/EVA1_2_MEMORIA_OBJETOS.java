/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package eva1_2_memoria_objetos;

/**
 *
 * @author invitado
 */
public class EVA1_2_MEMORIA_OBJETOS {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int iOtroval=10;//stack
        double dSalario =500.50;//stack
        prueba pObj=new prueba();//hit
        System.out.println("iOtroval = "+iOtroval);
        System.out.println("dSalario = "+dSalario);
        System.out.println("pObj = "+pObj);//accede a la direccion en memoria
        System.out.println("Valor de ival = "+pObj.ival);//accede al objeto
    }
}
class prueba{//se crea fuera
    int ival=4;//se crea dinamicamente entonces al hit
}