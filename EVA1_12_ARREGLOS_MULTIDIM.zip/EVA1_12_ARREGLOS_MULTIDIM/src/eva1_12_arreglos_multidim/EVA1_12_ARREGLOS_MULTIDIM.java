/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package eva1_12_arreglos_multidim;

/**
 *
 * @author invitado
 */
public class EVA1_12_ARREGLOS_MULTIDIM {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //MATRIXZ-----> ARREGLO DE DOS DIMENSIONES
        //PARA RECORRER EL ARGLO SERA CON FOR ANIDADO
        int[][]aiMatriz=new int[3][3];//arreglo multidimensional 3 filas x 3 columnas
        System.out.println(aiMatriz);//imprime una referncia
        aiMatriz[0][0]=10;
        aiMatriz[0][1]=20;
        aiMatriz[0][2]=30;
        aiMatriz[1][0]=40;
        aiMatriz[1][1]=50;
        aiMatriz[1][2]=60;
        aiMatriz[2][0]=70;
        aiMatriz[2][1]=90;
        aiMatriz[2][2]=90;
        System.out.println(aiMatriz[0]);
        System.out.println(aiMatriz[1]);
        System.out.println(aiMatriz[2]);
        
        //PARA RECORRER UN ARREGLO MULTIDIMENSIONAL,NESESITAMOS UN CICLO PARA
        //CADA DIMENSION.LOS FOR ESTAN ANIDADOS(UNO DENTRO DE OTRO
        for(int i =0; i < 3;i++){//primer corchete las filas
        for(int j=0;j<3;j++){//segundo corchete columnas
            System.out.println(aiMatriz[i][j]);//imprime la matriz
        }
    }
        
    }
}
