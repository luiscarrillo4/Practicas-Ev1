
import java.util.Scanner;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author invitado
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      
       // TODO code application logic here
    int[] aiDatos=new int[5];
    for(int i=0;i<aiDatos.length;i++){
     aiDatos[i]=(int)(Math.random()*10)+1;
        System.out.print(aiDatos[i]+" ");
    }
    Scanner sc=new Scanner(System.in);
        System.out.println("que valor buscas?");
    int ival= sc.nextInt();
    for(int i=0;i<aiDatos.length;i++){
        if(ival==aiDatos[i])
        System.out.println("El valor esta en la posicion" + i);
        /// si queremos detener, usariamos un break
       
    }
    }
    
}
