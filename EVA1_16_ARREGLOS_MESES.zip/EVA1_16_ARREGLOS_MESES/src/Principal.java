
import java.util.Scanner;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author invitado
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
   String[]asMeses={"Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"};
   //equivalente a:
   //STRING[] asMeses=new String[12];
   //aaMeses[0]="enero,
   //as meses[1]="febrero";
   int[]aiDias={31,28,31,30,31,31,30,31,30,31,30,31};//arreglo para dias
   
   // preguntar al ususario
   Scanner sc=new Scanner(System.in);
        System.out.println("Introduce el numero del mes:");
        int iMes= sc.nextInt();
        //imprimir el mes(iMes va desde 1 a 12, el arreglo va de 0 a 11
        //por eso se resta 1
        System.out.println("El mes es:" +  asMeses[iMes-1] +" y tiene:" + aiDias[iMes-1]+" dias");
    }
}
