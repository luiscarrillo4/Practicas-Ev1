
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Mary
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc=new Scanner(System.in);
        System.out.println("Edades a registrar:");
        int e=sc.nextInt();
        int Edad[]= new int[e];
        double suma=0;
        int median=0;
        int veces=0;
        int maxveces=0;
        double vr=0;
        double des=0;
        int MaximoNumeroDeRepeticiones=0;
        double moda=0;
        for (int i = 0; i < e; i++) {
            System.out.println("Ingresa edad: ");
            Edad[i]=sc.nextInt();
            
        }
        for (int i = 0; i < Edad.length; i++) {
            int numRepeticiones=0;
            for (int j = 0; j < Edad.length; j++) {
                if (Edad[i]==Edad[j]) {
                    numRepeticiones++;
                }
                if (numRepeticiones>MaximoNumeroDeRepeticiones) {
                    moda=Edad[i];
                    MaximoNumeroDeRepeticiones=numRepeticiones;
                }
            }
        }    
         
        for (int i = 0; i < e; i++) {
            suma=suma+Edad[i];
        }
       double media=suma/e;
        for (int i = 0; i < Edad.length; i++) {
       int vece=0;
            for (int j = 0; j < Edad.length; j++) {
                if (Edad[i]==Edad[j]) {
                    vece++;
                }
            }
            if (veces>maxveces) {
                suma=Edad[i];
            }
            for (int k = 0; k < Edad.length; k++) {
                double rango;
                rango=Math.pow(Edad[i]-suma, 2f);
                vr=vr+rango;
            }
            double l=Edad.length;
            vr=vr/l;
            des=Math.sqrt(vr);
        }
        System.out.println("La media es: "+media);
        System.out.println("Desviacion estandar: "+des);
        System.out.println("Moda: "+moda);
 
    }
    
}
