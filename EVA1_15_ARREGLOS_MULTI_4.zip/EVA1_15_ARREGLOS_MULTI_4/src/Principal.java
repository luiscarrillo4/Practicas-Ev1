
import java.util.Scanner;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author invitado
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int[][]aiEdades;
        int iNoGrp,iNoAlum;// cantidad de grupos,cantidad de alumnos
        Scanner sc=new Scanner(System.in);
        System.out.println("Introduce el numero de grupos:");//captura del teclado
        iNoGrp = sc.nextInt();//el numero de grupos son las filas del arreglo
                             //matriz
        aiEdades= new int [iNoGrp][];
        //for para preguntar para cad grupoo la cantidad de alumnos
        //for(int i=0;i<iNoGrup;i++)
        for(int i=0; i< aiEdades.length;i++){
            System.out.println("Cuantos alumnos tiene el grupo"+ (i+1)+":");
            iNoAlum=sc.nextInt();
            aiEdades[i]= new int[iNoAlum];//para cada fila,define numero de columnas
            
            
        }
        //capturar las edades: recorrer el arreglo
        for(int i=0;i<aiEdades.length;i++){//filas o grupos
            for(int j=0;j< aiEdades[i].length ;j++){
            System.out.println("Cual es la edad del grupo "+ (i+1)+" " +"Alumno "+ (j+1)+" " +"es: ");
            aiEdades [i][j]=sc.nextInt();//capturamos la edad
        } 
            
        }
        //imprimir las edades capturadas
          for(int i=0;i<aiEdades.length;i++){//filas o grupos
            for(int j=0;j< aiEdades[i].length ;j++){//alumnos para el grupo actual
            System.out.println("La edad del grupo "+ (i+1)+ " "+"Alumno "+ (j+1)+ " " +"es: "+ aiEdades[i][j]);
       
        }
            
    } 
          //Calcular el promdedio de edades
         int iAcum, iAcumTodos=0, iAcumNoAlu=0;
          for(int i =0; i<aiEdades.length;i++){//filas y grupos
              iAcum=0;
              iAcumNoAlu=iAcumNoAlu + aiEdades[i].length;
              for(int j=0;j<aiEdades[i].length;j++){//alumnos para el grupo actual
                  iAcum= iAcum + aiEdades[i][j];
              iAcumTodos= iAcumTodos+ aiEdades[i][j];
          }
          //sumatoria de los alumnos
          System.out.println("EL PROMEDIO PARA EL GRUPO "+ (i+1) +"="+(iAcum / aiEdades[i].length));
}
}
}
