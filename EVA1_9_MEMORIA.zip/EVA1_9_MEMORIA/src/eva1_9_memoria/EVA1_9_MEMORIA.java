/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package eva1_9_memoria;

/**
 *
 * @author invitado
 */
public class EVA1_9_MEMORIA {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
      EVA1_9_MEMORIA pObj= new EVA1_9_MEMORIA();
      //para desacerse de la memoria de un objeto
      pObj=null;//TODO OBJETO QUE  NO ES REFERNCIADO POR ALGUNA VARIABLE
      // ES ELIMINADO OR EL GARBAGE COLLECTOR
      
      EVA1_9_MEMORIA pObj2=new EVA1_9_MEMORIA();
      EVA1_9_MEMORIA pCopia= pObj2;//no dup`licamos el objeto, duplicamos la direccion
      //queremos eliminar pObj2
      pObj2=null;//no se elimina el objeto por que copia sigue apuntando
      pCopia=null;//ahora si el objeto, no quedan mas referencia al objeto
    }
}
