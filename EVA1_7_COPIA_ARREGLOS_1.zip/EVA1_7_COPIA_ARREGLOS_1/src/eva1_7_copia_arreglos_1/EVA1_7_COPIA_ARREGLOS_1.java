/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package eva1_7_copia_arreglos_1;

/**
 *
 * @author invitado
 */
public class EVA1_7_COPIA_ARREGLOS_1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int aiDatosOrigen[]=new int[5];
        aiDatosOrigen[0]=10;
        aiDatosOrigen[1]=20;
        aiDatosOrigen[2]=30;
        aiDatosOrigen[3]=40;
        aiDatosOrigen[4]=50;
        //Tambien dse puede hacer con el for
        //mi copia de arreglos
        int aiCopia[];
        aiCopia=aiDatosOrigen;
        for(int b: aiCopia){
            System.out.println(b);
        }
        //modifico aiDatosOrigen
        aiDatosOrigen[2]=99999;
        //imprimir copia
        System.out.println("remprimiendo la copia");
        for(int i=0; i<aiCopia.length;i++){
            System.out.println(aiCopia[i]);
        }
        System.out.println(aiDatosOrigen);
        System.out.println(aiCopia);//si imprime igual son dependientes
    }
    
}
