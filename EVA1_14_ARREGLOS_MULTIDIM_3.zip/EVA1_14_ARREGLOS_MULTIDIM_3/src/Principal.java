/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author invitado
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int[][][][] aiArreMulti=new int [1][3][2][8];//arremulti guarada la direccion de del primero
        for(int i =0; i<aiArreMulti.length;i++){
            for(int j=0; j< aiArreMulti[i].length;j++){
                for(int k =0; k<aiArreMulti[i][j].length;k++){
                    for(int l =0 ; l <aiArreMulti[i][j][k].length;l++){
                     //imprimir
                        aiArreMulti[i][j][k][l]=(int)(Math.random()*100);
                    }
                }
            }
        }
             
        for(int i =0; i<aiArreMulti.length;i++){
            for(int j=0; j< aiArreMulti[i].length;j++){
                for(int k =0; k<aiArreMulti[i][j].length;k++){
                    for(int l =0 ; l <aiArreMulti[i][j][k].length;l++){
                     //imprimir
                        System.out.println(aiArreMulti[i][j][k][l]);;
                    }
                }
            }
        }
    }
}

    
