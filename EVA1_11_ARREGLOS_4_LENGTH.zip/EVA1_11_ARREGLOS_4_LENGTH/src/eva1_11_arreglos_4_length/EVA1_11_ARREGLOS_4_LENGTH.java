/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package eva1_11_arreglos_4_length;

/**
 *
 * @author invitado
 */
public class EVA1_11_ARREGLOS_4_LENGTH {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int aiDatos[]=new int[5];
        aiDatos[0]=10;
        aiDatos[1]=20;
        aiDatos[2]=30;
        aiDatos[3]=40;
        aiDatos[4]=50;
        int[]aiCopia=new int[5];
        for(int i=0;i<aiDatos.length;i++){
            //dato por dato copiar
            aiCopia[i]=aiDatos[i];
          //  System.out.println("[" + i +"]=" +aiDatos[i]);// impresion de datos
        }
        aiDatos = new int[10];
        for(int i =0;i<aiCopia.length;++i){
            
        }
        
        System.out.println("Cuando se añade tamaño 10");
        for(int i=0;i<aiDatos.length;i++){
            System.out.println("["+i+"]="+aiDatos[i]);    
        }
    
    }
}
