/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package eva1_4_arreglos_1;

/**
 *
 * @author invitado
 */
public class EVA1_4_ARREGLOS_1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int[]aiEjemplo = new int[5];
        int[] aiArrel,aiArre2, aiArre3, aiArre4;  //estos 4 identificadores son arrreglos
        int aiArre5[],i;//solo arreis 5 es un arreglo y i es una variable entera
        //definimos el tamaño de arreglo con el opreador new
        aiArrel =new int[100];//asignamos 100 espacios de tipo entero
        //------
        System.out.println(aiEjemplo);//puro nombre solo da referencia
        System.out.println(aiEjemplo[0]);//accede al elemento del arreglo
    }//los arreglos en java son obetos
    
}
