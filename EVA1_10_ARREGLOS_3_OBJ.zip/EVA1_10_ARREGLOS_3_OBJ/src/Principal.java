/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Mary
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Persona apGente[]= new Persona [5];
        apGente [0]=new Persona();//constructor default
        apGente [1]=new Persona("Alfredo","Hernandez",20);//constructor con parametros
        apGente [2]=new Persona("Brandon","Dominguez",20);//constructor con parametros
        apGente [3]=new Persona("America","Fernanda",19);//constructor con parametros
        apGente [4]=new Persona("Mario","Estrada",21);//constructor con parametros
        
         
        
       for(int i =0;i<apGente.length;i++){
           System.out.println(" Nombre: " + apGente[i].getsNomb());
           System.out.println(" Apellido: " + apGente[i].getsApe());
           System.out.println(" Edad: " + apGente[i].getiEdad());
           
       }
       //creo la copia
       Persona apCopiaGen[]=new Persona[5];
        System.out.println("IMPRIMIR COPIA");
       for (int i=0;i<apGente.length;i++){
           System.out.println(" Nombre: " + apGente[i].getsNomb());
           System.out.println(" Apellido: " + apGente[i].getsApe());
           System.out.println(" Edad :" + apGente[i].getiEdad());
           
       }
           apGente[0].setsNomb("xxxxx");
        
    }

    public Principal() {
    }
}
class Persona{
    private String sNomb;
    private String sApe;
    private int iEdad;

    public Persona() {//constructor
    sNomb="Luis Daniel";
    sApe ="Carrillo Correa";
    iEdad = 20;
    }
//constructor con parametros de entrada
    public Persona(String sNomb, String sApe, int iEdad) {
        this.sNomb = sNomb;
        this.sApe = sApe;
        this.iEdad = iEdad;
    }

    public String getsNomb() {
        return sNomb;
    }

    public String getsApe() {
        return sApe;
    }

    public int getiEdad() {
        return iEdad;
    }

    public void setsNomb(String sNomb) {
        this.sNomb = sNomb;
    }

    public void setsApe(String sApe) {
        this.sApe = sApe;
    }

    public void setiEdad(int iEdad) {
        this.iEdad = iEdad;
    }
    

    

}

    
    

