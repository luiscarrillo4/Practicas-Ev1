/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Mary
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int iNumMax= Integer.MAX_VALUE;
        System.out.println(iNumMax);
        int iNumMin= Integer.MIN_VALUE;
        System.out.println(iNumMin);
        iNumMax++;
        System.out.println(iNumMax);
      long INumerote= Integer.MAX_VALUE;
      INumerote++;
        System.out.println("Numerote "+INumerote);
    }
    
}
