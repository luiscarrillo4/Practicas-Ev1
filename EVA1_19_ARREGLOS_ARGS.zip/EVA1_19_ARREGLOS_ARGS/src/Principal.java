/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author invitado
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
       int[]aiDatos={1,2,3,4,5,6,7,8,9};//arreglo de varias 
      
       imprimeArreglo(aiDatos);
        
        aiDatos=new int[10];
        aiDatos[0]=10;
        aiDatos[1]=20;
        aiDatos[2]=30;
        aiDatos[3]=40;
        aiDatos[4]=50;
        aiDatos[5]=60;
        aiDatos[6]=70;
        aiDatos[7]=80;
        aiDatos[8]=90;
        aiDatos[9]=100;
        imprimeArreglo(aiDatos);
    }
    //nueva funcion
    public static void imprimeArreglo(int[] aiArre){
        for (int i : aiArre) {
            System.out.println("valor ="+i);
        }
        
    }
}
