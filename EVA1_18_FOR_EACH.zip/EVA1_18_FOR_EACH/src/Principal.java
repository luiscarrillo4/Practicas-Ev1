/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Mary
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int Arreglo[]={1,2,3,4,5,6,7,8,9,10};
        for (int iVal : Arreglo) {
            System.out.println("Valor="+iVal);}
        String cadena[]={"Luis","Daniel","Carrillo","Correa","!!!"};
        for (String iVal : cadena) {
           System.out.println("Valor="+iVal);}
        int Matriz[][]=new int[3][3];
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                Matriz[i][j]=(int)(Math.random()*10);}}
        for (int[] is : Matriz) {
            for (int i : is) {
                System.out.println("Valor Matriz="+i);}}
        System.out.println("");
        int Matriz1[][][]=new int[3][3][3];
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                for (int k = 0; k < 3; k++) {
                    Matriz1[i][j][k]=(int)(Math.random()*10);}}}
        System.out.println("valor Matriz1=");
        for (int[][] is : Matriz1) {
            for (int[] i : is) {
                for (int j : i) {
                    System.out.print(""+j);}
                System.out.println("");
                System.out.println("");}}}
} 
